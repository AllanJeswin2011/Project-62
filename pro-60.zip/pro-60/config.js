import firebase from "firebase"

const firebaseConfig = {

 apiKey: "AIzaSyCPkGwAywYSlN1wNkwyGlrdAuSCSvHY3rY",
  authDomain: "school-attendance-app-2592c.firebaseapp.com",
  databaseURL: "https://school-attendance-app-2592c-default-rtdb.firebaseio.com",
  projectId: "school-attendance-app-2592c",
  storageBucket: "school-attendance-app-2592c.appspot.com",
  messagingSenderId: "29185932619",
  appId: "1:29185932619:web:e7bf43d761875592fcfcce"
};
firebase.initializeApp(firebaseConfig);

  export default firebase.database()
 

  